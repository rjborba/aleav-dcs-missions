-- NAe A12 Sao Paulo Marinha do Brasil - v1.32

-- Objects on Water

				-- sao_paulo

				mount_vfs_model_path	(current_mod_path.."/Shapes")
				mount_vfs_texture_path  (current_mod_path.."/Textures/sao_paulo.zip")

				GT = {};
				GT_t.ws = 0;

				set_recursive_metatable(GT, GT_t.generic_ship)

				GT.animation_arguments.radar1_rotation = 11; -- вращение радара 1
				GT.radar1_period = 3;
				GT.animation_arguments.radar2_rotation = -1; -- вращение радара 2 отсутствует
				GT.animation_arguments.radar3_rotation = -1; -- вращение радара 3 отсутствует
				GT.animation_arguments.luna_lights = 151;

				GT.visual = {}
				GT.visual.shape = "sao_paulo";
				GT.visual.shape_dstr = ""

-- GENERAL DATA***************************************************************************
				GT.life = 5000;
				GT.mass = 7.25e+006;
				GT.max_velocity = 16.4622;
				GT.race_velocity = 15.4333;
				GT.economy_velocity = 9.26;
				GT.economy_distance = 1.59272e+007;
				GT.race_distance = 1.59272e+007;
				GT.shipLength = 264;
				GT.Width = 50;
				GT.Height = 50;
				GT.Length = 264;
				GT.DeckLevel = 16.35;
				GT.X_nose = 109.379;
				GT.X_tail = -128.80;
				GT.Tail_Width = 20;
				GT.Gamma_max = 0.35;
				GT.Om = 0.05;
				GT.speedup = 0.1014062;
				GT.R_min = 212.4;
				GT.distFindObstacles = 1048.6;
				GT.TACAN = true;
				GT.TACAN_position = {-7.0, 55.0, 13.0}
				GT.OLS = {Type = GT_t.OLS_TYPE.IFLOLS, CutLightsArg = 404, DatumAndWaveOffLightsArg = 405, MeatBallArg = 151, GlideslopeBasicAngle = 3.5, VerticalCoverageAngle = 1.7};

				GT.numParking = 8;
				GT.Plane_Num_ = 22;
				GT.Helicopter_Num_ = 17;
				GT.animation_arguments.catapult_shuttles = {145, 146, 147, 148}
				GT.animation_arguments.arresting_wires = {400, 401, 402, 403}
				GT.exhaust =
				{
					[1] = { size = 0.655 , pos = {-7.464, 32.543, 13.093 } }
 };

-- ARRESTING CABLES POSITION (Y AXIS, HEIGHT, X AXIS)********************************************************

	GT.ArrestingGears = {
	{
		Left = {	pos = {-92.66,   16.5, -17.07} }, -- WIRE 1 304ft/56ft
		Right = {	pos = {-85.39,   16.5,  11.88} } --		    290ft/39ft
	},
	{
		Left = {	pos = {-85.64,   16.5, -17.67} }, -- WIRE 2 281ft/58ft
		Right = {	pos = {-81.38,   16.5, 10.97} } --		    267ft/36ft
	},
	{
		Left = {	pos = {-78.02,   16.5, -18.59} }, -- WIRE 3 256ft/61ftt
		Right = {	pos = {-73.15,   16.5, 9.75} } --		    240ft/32ft
	},
	{
		Left = {	pos = {-70.40,   16.5, -19.812} }, -- WIRE 4 231ft/65ft
		Right = {	pos = {-65.53,   16.5, 8.22} } --		     215ft/27ft
	}
};
GT.ArrestingGears.ArrestingGearsNumber = #GT.ArrestingGears


---GT.Landing_Point = {71.0, 16.26,-30.0} --{71.0, 16.26,-30.0}
---GT.Landing_Point = {71.0, 13.20, -10.0} --{71.0, 16.26,-30.0}
GT.Landing_Point = {-85.304, 16.35, 0} --{71.0, 16.26,-30.0}

-- ALT+F9 CAMERA,															X,Y,Z,ROTATION,ANGLE
GT.LSOView = {cockpit = "empty", position = {--[[connector = "",]] offset = {-25.0, 16.45, -12.0, -171.0, 3.0}}};


-- DAMAGE SECTION ****************************************************************************

GT.DM = {
----- Hull Right side.
	{ area_name = "Scafo_Prua_Dx",			area_arg = 76,	area_life = 100, area_fire = { pos = {75.0, 4.0, 8.0}, size = 1.5}},
	{ area_name = "Scafo_Centrale_Dx",		area_arg = 71,	area_life = 100, area_fire = { pos = {20.0,  2.0, 13.0}, size = 1.5}},
	{ area_name = "Scafo_Poppa_Dx", 		area_arg = 72,	area_life = 100, area_fire = { pos = {-70.0, 2.0, 8.0}, size = 1.5}},
----- Hull Left side.
	{ area_name = "Scafo_Prua_Sx", 		    area_arg = 73,	area_life = 100, area_fire = { pos = {90.0, 4.0, -10.0}, size = 1.5}},
	{ area_name = "Scafo_Centrale_Sx", 		area_arg = 74,	area_life = 100, area_fire = { pos = {0.0,  2.0, -13.0}, size = 1.5}},
	{ area_name = "Scafo_Poppa_Sx", 		area_arg = 75,	area_life = 100, area_fire = { pos = {-100.0, 2.0, -10.5}, size = 1.5}},
-------- Sovrastrutture
	{ area_name = "Isola_Ponte",        	area_arg = 82,	area_life = 200, area_fire = { pos = {-23.0, 12.0, 0.0}, size = 1.5}},

-------- Flight Deck
	{ area_name = "Ponte_Prua",	           	area_arg = 84,	area_life = 300, area_fire = { pos = {67.0, 11.0, 0.0}, size =  1.5}},
    { area_name = "Ponte_Poppa",		    area_arg = 85,	area_life = 100, area_fire = { pos = {-95.0, 11.0, 0.0}, size = 1.5}}

}
				GT.airWeaponDist = 0
				GT.airFindDist = 0
				-- weapon systems

				GT.Name = "sao_paulo"
				GT.DisplayName = _("Sao Paulo A12 Carrier")
GT.Rate = 5500

GT.Sensors = {  OPTIC = {"long-range naval optics", "long-range naval LLTV"},
                RADAR = {
                            "Tor 9A331",
                            "2S6 Tunguska",
                            "carrier search radar",
                        }
            };

GT.DetectionRange  = GT.airFindDist;
GT.ThreatRange = GT.airWeaponDist;
GT.Singleton   ="yes";
GT.mapclasskey = "P0091000065";
GT.attribute = {wsType_Navy,wsType_Ship,wsType_AirCarrier,VINSON,
                    "Aircraft Carriers",
                    "Arresting Gear","catapult",
                    "RADAR_BAND1_FOR_ARM",
                    "RADAR_BAND2_FOR_ARM",
				};
GT.Categories = {
					{name = "AircraftCarrier"},
					{name = "AircraftCarrier With Catapult"},
					{name = "Armed Ship"},
					{name = "HelicopterCarrier"}

};


-- RUNWAY DATA UNITS IN METERS**************************************************************************************************************************

add_surface_unit(GT)

GT.RunWays =
{
-- landing strip definition (first in table)
--	VppStartPoint(RUNWAY CENTER POINT)			azimuth (degree}   	Length_Vpp; 	Width_Vpp;
	{{-53.34, 16.35, -7.31}, 					351, 		  	    171.60, 		21.33,
-- alsArgument, lowGlidePath, slightlyLowGlidePath, onLowerGlidePath, onUpperGlidePath, slightlyHighGlidePath, highGlidePath
	0, 			0.5, 		  		2.8, 					3.0, 			  3.0, 				3.2, 				3.5},
-- runways
	{{ 52.68,	16.35,  -7.75}, 		360.000, 			65.85, 			25.0, 		0, 2.5, 2.8, 3.0, 3.0, 3.2, 3.5}, --SHUTTLE 1
	{{-43.30,	16.35, -18.70}, 	    354.500, 			75.28, 			25.0, 		0, 2.5, 2.8, 3.0, 3.0, 3.2, 3.5}, --SHUTTLE 2
};

GT.RunWays.RunwaysNumber = #GT.RunWays

--TAXI ROUTES AFTER LANDING (The last point is the final parking position. V_target means Speed)******************************************************

GT.RunWays.RunwaysNumber = #GT.RunWays

GT.TaxiRoutes =
	-- taxi routes and parking spots in LCS
	--    x				y        z			V_target
{
	{ -- 1 parking spot
		{{15, 		16.35,		0},		3.0},
		{{35.68,    16.35,		1},		2.0},
		{{77,	    16.35,		5},		2.0},
		{{72,	    16.35,		10},   -2.0}
	},
	{ -- 2 parking spot 
		{{15, 		16.35,		0},		3.0},
		{{35.68,    16.35,		1},		2.0},
		{{67,	    16.35,		5},		2.0},
		{{62,	    16.35,		10},   -2.0}		-- 3.0*60.0 last number - 3*60sec = 3 minutes for despawn object at this point
	},
	{ -- 3 parking spot (THIRD ON RIGHT FRONT DECK)
		{{15, 		16.35,		0},		3.0},
		{{35.68,    16.35,		1},		2.0},
		{{57,	    16.35,		5},		2.0},
		{{52,	    16.35,		10},	-2.0}
	},
	{ -- 4 parking spot (ELEVATOR)
		{{15, 		16.35,		0},		3.0},
		{{37.5,    16.35,		1},		2.0}
	--	{{60,	    16.35,		5},		2.0},
	--	{{55,	    16.35,		10},	-2.0}

	},
	{ -- 5 parking spot (ISLAND 1)
		{{ 15.0,	16.35,		0},     3.0},
		{{ 17.68,	16.35,	 0.91},  	2.0}
		--{{-70.0,	16.26,	 16.0}, 	2.0}
	},
	{ -- 6 parking spot (ISLAND 2)
		{{-10.0,	16.35,	    1},  	3.0},
		{{0.0,		16.35,      2},  	2.0}
		--{{-50.0,	16.26,	 14.0}, 	2.0}
	},
	{ -- 7 parking spot
		{{37.30,	16.35,	  11},		3.0},
		{{-42.30,	16.35,    16},     -2.0}
		--{{-25.0,	16.26,	 8.0},		2.0},
		--{{-30.0,	16.26,	25.0},		2.0}
	},
	{ -- 8 parking spot
		{{-15.0,		16.35,		-6.0},		3.0},
		{{-15.0,		16.35,		 -6.0},		2.0}
		--{{-30.0,	16.26,		  8.0},		2.0}
	}
};
GT.TaxiRoutes.RoutesNumber = #GT.TaxiRoutes

-- TAXI FOR TAKE OFF ROUTES*************************************************************************

GT.TaxiForTORoutes =
	-- taxi routes and parking spots in LCS
	--    x			y        z			V_target
{
	{ RunwayIdx = 1, Points =
		{ -- 1 spawn spot -> front deck 1
			{{ 52,	    16.35,		 9},	1.0},
			{{ 57,	    16.35,		 5},	1.0}
		}
	},
	{ RunwayIdx = 1, Points =
		{ -- 2 spawn spot -> front deck 2
			{{ 62,  	16.35,      9},		1.0},
			{{ 67,      16.35,      5},     1.0}
		}
	},
	{ RunwayIdx = 1, Points =
		{ -- 3 spawn spot -> front deck 3
			{{ 72,	    16.35,		 9},	1.0},
			{{ 77,	    16.35,		 5},	1.0}
		}
	},
	{ RunwayIdx = 1, Points =
		{ -- 4 spawn spot -> elevator
			{{ 37.50,	16.35,   0.91},		1.0},
			{{ 32.50,   16.35,   0.91},     1.0}
		}
	},
	{ RunwayIdx = 2, Points =
		{ -- 5 spawn spot -> island 1
			{{ 17.68,	 16.35,   0.91},	 1.0},
			{{ 15.68,    16.35,   0.91},     1.0}
		}
	},
	{ RunwayIdx = 2, Points =
		{ -- 6 spawn spot -> island 2
			{{  0.0,	 16.35,  0.91},		1.0},
			{{ -5.68,    16.35,  0.91},     1.0}
		}
	},
	{ RunwayIdx = 2, Points =
		{ -- 7 spawn spot -> elevator 2
			{{ -42.30,	 16.35,    16},		 1.0},
			{{ -37.30,   16.35,    11},      1.0}
		}
	},
	{ RunwayIdx = 2, Points =
		{ -- 8 spawn spot -> runway
			{{ -120.30,	 16.35,   -10},		 1.0},
			{{ -110.30,   16.35,   -5},      1.0}
		}
	},
	{ RunwayIdx = 1, Points =
		{ -- 9 spawn spot -> front deck 4
			{{ 82,	    16.35,		 9},	1.0},
			{{ 87,	    16.35,		 5},	1.0}
		}
	},
	{ RunwayIdx = 1, Points =
		{ -- 10 spawn spot -> front deck 5
			{{ 92,	    16.35,		 9},	1.0},
			{{ 97,	    16.35,		 5},	1.0}
		}
	}
};
GT.TaxiForTORoutes.RoutesForTONumber = #GT.TaxiForTORoutes
