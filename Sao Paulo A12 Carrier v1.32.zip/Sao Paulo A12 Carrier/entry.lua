declare_plugin("São Paulo A12 Carrier", --(Eric et Patrick Cuesta Technical and graphical parts), enhanced by Kleber

{
image     	 = "São Paulo A12 Carrier.bmp",
installed 	 = true, 
dirName	  	 = current_mod_path,

fileMenuName = _("São Paulo A12 Carrier"),
version		 = "1.31",		 
state		 = "installed",
info		 = _("São Paulo A12 Carrier"),


encyclopedia_path = current_mod_path .. '/Encyclopedia',
})
----------------------------------------------------------------------------------------

dofile(current_mod_path..'/sao_paulo.lua')
--dofile(current_mod_path..'/CV6_Enterprise_Ammo.lua')




plugin_done()